<?php
namespace Mageplaza\HelloWorld\Block;
class Test extends \Magento\Framework\View\Element\Template
{

}